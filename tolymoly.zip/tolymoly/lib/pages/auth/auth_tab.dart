import 'package:flutter/material.dart';
import 'package:tolymoly/pages/auth/login.dart';

class AuthTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: true,
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            ),
            bottom: TabBar(
              tabs: [Tab(text: 'Registration'), Tab(text: 'Login')],
            ),
            title: Text('Welcome'),
          ),
          body: TabBarView(
            children: [
              Login(),
            ],
          ),
        ),
      ),
    );
  }
}
