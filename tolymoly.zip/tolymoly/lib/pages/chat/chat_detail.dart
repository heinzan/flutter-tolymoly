import 'package:flutter/material.dart';
import 'package:tolymoly/api/chat_api.dart';
import 'package:tolymoly/pages/chat/chat_detail_appbar.dart';
import 'package:tolymoly/pages/chat/chat_message.dart';

// import 'chat_message.dart';

class ChatDetail extends StatefulWidget {
  final data;
  // ChatDetail(this.data);
  ChatDetail({this.data});

  @override
  State createState() => new ChatDetailState();
}

class ChatDetailState extends State<ChatDetail> {
  // final List<ChatMessage> _messages = <ChatMessage>[];
  final List<ChatMessage> _messages = <ChatMessage>[];
  final TextEditingController _textController = new TextEditingController();
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _getData();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.blueGrey.shade50,
      appBar: new AppBar(
          automaticallyImplyLeading: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context, false),
          ),
          // title: new Text(widget.data['adTitle'])),
          title: ChatDetailAppbar(data: widget.data)),
      body: new Column(children: <Widget>[
        new ListTile(
          leading: new Image.network(
            widget.data['adImage'].toString(),
          ),

          // trailing: new CircleAvatar(
          //   backgroundImage:
          //       NetworkImage(widget.data['receiverImage'].toString()),
          // ),
          // trailing: _buildTrailing(context, chats[index]['unreadCount'],
          //     chats[index]['createdDate']),
          title: Text(widget.data['adTitle']),
          // subtitle: Text(chats[index]['message'].toString()),
          onTap: () {
            // print(chats[index]);
            // var data = {
            //   'adId': chats[index]['adId'],
            //   'receiverId': chats[index]
            //       [widget.isBuying ? 'sellerId' : 'buyerId'],
            //   'isBuying': widget.isBuying ? true : false
            // };
            // Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //         builder: (context) => new ChatDetail(data: data)));
          },
        ),
        Divider(color: Colors.black),
        new Flexible(
            child: new ListView.builder(
          padding: new EdgeInsets.all(8.0),
          reverse: true,
          itemBuilder: (_, int index) => _messages[index],
          itemCount: _messages.length,
        )),
        new Divider(height: 1.0),
        new Container(
          decoration: new BoxDecoration(color: Theme.of(context).cardColor),
          child: _buildTextComposer(),
        ),
      ]),
    );
  }

  void _getData() async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
      });
      var response;
      if (widget.data['isBuying']) {
        response = await ChatApi.getOneByBuying(
            widget.data['adId'], widget.data['receiverId']);
      } else {
        response = await ChatApi.getOneBySelling(
            widget.data['adId'], widget.data['receiverId']);
      }

      List<ChatMessage> history = new List();
      // nextPage = response.data['next'];
      for (int i = 0; i < response.data.length; i++) {
        // history.add(new ChatMessage(text: response.data[i]['message']));
        //ChatMessage({this.message, this.time, this.delivered, this.isMe});
        response.data[i]['isRead'] = false;
        history.add(new ChatMessage(
            data: response.data[i], receiverId: widget.data['receiverId']));
      }

      setState(() {
        isLoading = false;
        _messages.addAll(history);
      });
    }
  }

  void _handleSubmitted(String text) {
    _textController.clear();
    ChatMessage message = new ChatMessage(data: {
      'senderId': 0,
      'message': text,
      'createdDate': new DateTime.now().toString(),
      'isRead': false
    }, receiverId: widget.data['receiverId']);

    setState(() {
      _messages.insert(0, message);
    });

    _saveMessage(text);
  }

  void _saveMessage(String text) {
    print(widget.data.toString());
    print(widget.data['adId']);
    print(widget.data['receiverId']);

    ChatApi.post({
      "adId": widget.data['adId'],
      "receiverId": widget.data['receiverId'],
      "message": text
    }).then((response) {});
  }

  Widget _buildTextComposer() {
    return new Container(
        margin: const EdgeInsets.symmetric(horizontal: 8.0),
        child: new Row(children: <Widget>[
          new Flexible(
            child: new TextField(
              controller: _textController,
              onSubmitted: _handleSubmitted,
              decoration:
                  new InputDecoration.collapsed(hintText: "Send a message"),
            ),
          ),
          new Container(
            margin: new EdgeInsets.symmetric(horizontal: 4.0),
            child: new IconButton(
                icon: new Icon(Icons.send),
                onPressed: () => _handleSubmitted(_textController.text)),
          ),
        ]));
  }
}
