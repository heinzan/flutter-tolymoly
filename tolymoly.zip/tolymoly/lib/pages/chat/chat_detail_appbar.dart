import 'package:flutter/material.dart';

class ChatDetailAppbar extends StatelessWidget {
  final data;
  ChatDetailAppbar({this.data});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        new CircleAvatar(
          backgroundImage: NetworkImage(data['receiverImage'].toString()),
        ),
        SizedBox(
          width: 8,
        ),
        Text(
          data['receiverName'],
        )
      ],
    );
  }
}
