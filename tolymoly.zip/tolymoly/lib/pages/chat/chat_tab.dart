import 'package:flutter/material.dart';
import 'package:tolymoly/pages/chat/chat_list.dart';
import 'package:tolymoly/pages/chat/test.dart';

class ChatTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: true,
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            ),
            bottom: TabBar(
              tabs: [Tab(text: 'Buying'), Tab(text: 'Selling')],
            ),
            title: Text('Chat'),
            actions: <Widget>[
              IconButton(
                icon: Icon(Icons.directions_car),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Test()),
                  );
                },
              ),
            ],
          ),
          body: TabBarView(
            children: [
              ChatList(true),
              ChatList(false),
            ],
          ),
        ),
      ),
    );
  }
}
