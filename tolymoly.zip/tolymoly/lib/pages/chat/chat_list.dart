import 'package:flutter/material.dart';
import 'package:tolymoly/api/chat_api.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:tolymoly/pages/chat/chat_detail.dart';

class ChatList extends StatefulWidget {
  final bool isBuying;

  ChatList(this.isBuying);

  @override
  _ChatListState createState() => _ChatListState();
}

class _ChatListState extends State<ChatList> {
  ScrollController _scrollController = new ScrollController();

  bool isLoading = false;

  int pageNumber = 1;

  List chats = new List();

  @override
  void initState() {
    this._getData(pageNumber);
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        _getData(pageNumber);
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: const Text("Pagination"),
      // ),
      body: Container(
        child: _buildList(),
      ),
      resizeToAvoidBottomPadding: false,
    );
  }

  void _getData(int pageNumber) async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
      });
      var response;
      if (widget.isBuying) {
        response = await ChatApi.getBuying(pageNumber);
      } else {
        response = await ChatApi.getSelling(pageNumber);
      }

      print('_getData...');
      print(response.toString());
      List tempList = new List();
      // nextPage = response.data['next'];
      for (int i = 0; i < response.data.length; i++) {
        tempList.add(response.data[i]);
      }

      setState(() {
        isLoading = false;
        chats.addAll(tempList);
      });
    }
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  Widget _buildList() {
    return ListView.builder(
      //+1 for progressbar
      itemCount: chats.length + 1,
      itemBuilder: (BuildContext context, int index) {
        if (index == chats.length) {
          return _buildProgressIndicator();
        } else {
          return new ListTile(
            leading: new Image.network(
              chats[index]['adImage'].toString(),
            ),
            // trailing: new Image.network(
            //   chats[index][widget.isBuying ? 'sellerImage' : 'buyerImage']
            //       .toString(),
            // ),
            trailing: _buildTrailing(context, chats[index]['unreadCount'],
                chats[index]['createdDate']),
            title: Text(chats[index]['adTitle'].toString()),
            subtitle: Text(chats[index]['message'].toString()),
            onTap: () {
              // print(chats[index]);
              var data = {
                'adId': chats[index]['adId'],
                'adTitle': chats[index]['adTitle'],
                'adImage': chats[index]['adImage'],
                'receiverId': chats[index]
                    [widget.isBuying ? 'sellerId' : 'buyerId'],
                'receiverName': chats[index]
                    [widget.isBuying ? 'sellerName' : 'buyerName'],
                'receiverImage': chats[index]
                    [widget.isBuying ? 'sellerImage' : 'buyerImage'],
                'isBuying': widget.isBuying ? true : false
              };
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => new ChatDetail(data: data)));
            },
          );
        }
      },
      controller: _scrollController,
    );
  }

  Widget _buildTrailing(
      BuildContext context, var unreadCount, var updatedDate) {
    Widget unread;
    if (unreadCount == 0) {
      unread = new Text("");

      /// If the unread parameter is the default "" we set our unread widget to null
      /// thereby nothing will be displayed for unread on the screen.
    } else {
      unread = new CircleAvatar(
        child: new FittedBox(
          child: new Text(
            unreadCount.toString(),
            style: new TextStyle(fontSize: 10.0),
          ),
          fit: BoxFit.fill,
        ),
        backgroundColor: Colors.green,
        maxRadius: 8.0,
      );
    }
    return new Column(
      children: <Widget>[
        new Padding(
          child: Text(
            timeago.format(DateTime.parse(updatedDate)),
            style: new TextStyle(fontSize: 10.0),
          ),
          padding: EdgeInsets.only(bottom: 10.0),
        ),
        unread
      ],
    );
  }
}
