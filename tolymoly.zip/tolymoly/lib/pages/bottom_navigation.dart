import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tolymoly/pages/auth/login.dart';
import 'package:tolymoly/pages/chat/chat_tab.dart';
import 'package:tolymoly/pages/home/home.dart';
import 'package:tolymoly/pages/me/me.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class BottomNavigation extends StatefulWidget {
  @override
  _BottomNavigationState createState() => _BottomNavigationState();
}

class _BottomNavigationState extends State<BottomNavigation> {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  int _currentIndex = 0;
  static const _indexChat = 1;
  static const _indexMe = 2;
  final List<Widget> _children = [
    Home(),
    ChatTab(),
    Me(),
  ];

  @override
  initState() {
    super.initState();
    _pushNotification();
  }

  void _pushNotification() {
    // _firebaseMessaging.configure(
    //     onMessage: (Map<String, dynamic> message) async {
    //   print('on message $message');
    // });

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print('on message $message');
      },
      onResume: (Map<String, dynamic> message) async {
        print('on resume $message');
      },
      onLaunch: (Map<String, dynamic> message) async {
        print('on launch $message');
      },
    );
  }

  // _saveToken() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   prefs.setString('token', token);
  //   print('token saved: $token');
  // }

  void onTabTapped(int index) {
    switch (index) {
      case 0:
        setState(() {
          _currentIndex = index;
        });
        break;
      case _indexChat:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ChatTab()),
        );
        break;
      case _indexMe:
        // setState(() {
        //   _currentIndex = index;
        // });

        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Login()),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Tolymoly'),
      // ),
      body: _children[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTabTapped,

        currentIndex:
            _currentIndex, // this will be set when a new tab is tapped
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.home),
            title: new Text('Home'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.mail),
            title: new Text('Chat'),
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), title: Text('Me'))
        ],
      ),
    );
  }
}
