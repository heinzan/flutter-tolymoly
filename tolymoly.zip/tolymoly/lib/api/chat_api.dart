import 'package:dio/dio.dart';
import 'package:tolymoly/util/http_util.dart';

class ChatApi {
  static final String url = '/chats';

  static Future<Response> post(Map data) async {
    return await HttpUtil.connection().post(url, data: data);
  }

  static Future<Response> getOneByBuying(int adId, int sellerId) async {
    return await HttpUtil.connection().get(url + '/buying/chat-history',
        queryParameters: {'adId': adId, 'sellerId': sellerId});
  }

  static Future<Response> getOneBySelling(int adId, int buyerId) async {
    return await HttpUtil.connection().get(url + '/selling/chat-history',
        queryParameters: {'adId': adId, 'buyerId': buyerId});
  }

  static Future<Response> getBuying(int pageNumber) async {
    return await HttpUtil.connection()
        .get(url + '/buying', queryParameters: {'pageNumber': pageNumber});
  }

  static Future<Response> getSelling(int pageNumber) async {
    return await HttpUtil.connection()
        .get(url + '/selling', queryParameters: {'pageNumber': pageNumber});
  }
}
