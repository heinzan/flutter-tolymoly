import 'package:flutter/material.dart';
import 'package:tolymoly/pages/bottom_navigation.dart';
import 'package:oktoast/oktoast.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return OKToast(
        child: MaterialApp(
      title: 'FlutterShare',
      debugShowCheckedModeBanner: false,
      home: BottomNavigation(),
    ));
  }
}
