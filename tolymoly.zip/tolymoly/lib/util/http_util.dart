import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';

class HttpUtil {
  static final String token =
      "eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIxIiwiaWF0IjoxNTY2NTUyMDE5LCJleHAiOjE1OTgxMDg5NzF9.pCvl75_UvoXaNEHYc6WP0NpKrHk5YCB-iHCpSZwHnCQ";
  static final url = "http://192.168.88.25:8080/api";
  static Dio dio;

  // HttpConnection() {
  //   print("init HttpConnection");

  //   if (dio == null) {
  //     init();
  //   }
  // }

  static connection() {
    if (dio == null) {
      init();
    }

    return dio;
  }

  static init() {
    print("init dio");
    dio = new Dio();

    // Set default configs
    dio.options.baseUrl = url;
    dio.options.connectTimeout = 5000;
    dio.options.receiveTimeout = 3000;

    dio.interceptors.add(InterceptorsWrapper(onRequest: (Options options) {
      //Set the token to headers
      if (token != "") options.headers["Authorization"] = "Bearer $token";

      return options; //continue
    }));

    dio.interceptors.add(LogInterceptor(requestBody: true));
    dio.interceptors.add(LogInterceptor(responseBody: true));

    dio.interceptors.add(InterceptorsWrapper(onError: (DioError e) {
      print('DioError......');
      print(e.response.data);
      showToast(
        e.response.data['error'],
        position: ToastPosition.top,
        backgroundColor: Colors.red.withOpacity(0.8),
      );
      return e; //continue
    }));
  }
}
